import base64

addon_name   = base64.b64decode('R2FtbWEgU3RyZWFtcw==')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLkdhbW1hU3RyZWFtcw==')

host         = base64.b64decode('aHR0cDovL2dhbW1haXB0di5kZG5zLm5ldA==')
port         = base64.b64decode('ODEyNw==')